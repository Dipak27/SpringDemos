
public interface EmployeeDAO 
{
	public int insertEmp(Employee e);
	public void SelectAllEmp();

}
