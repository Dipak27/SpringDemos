import java.util.Iterator;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDAOImpl implements EmployeeDAO
{
	public JdbcTemplate jt;
	
	public void setJt(JdbcTemplate jt) 
	{
		this.jt = jt;
	}

	@Override
	public int insertEmp(Employee e) 
	{
		int empno=e.getEmpno();
		String empname=e.getEmpname();
		
		Object[] param={empno,empname};
		int k= jt.update("insert into emp values(?,?)",param);
		return k;
	}

	@Override
	public void SelectAllEmp() {
	List l=jt.queryForList("select * from emp");
	Iterator it=l.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
	}

}
