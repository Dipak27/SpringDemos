import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientApp 
{
	public static void main(String args[])
	{
		ApplicationContext ctx= new ClassPathXmlApplicationContext("spconfig.xml");
		Object o=ctx.getBean("id4");
		EmployeeService sr= (EmployeeService)o;
		
		Employee e= new Employee();
		e.setEmpno(101);
		e.setEmpname("ram");
		sr.displayallemp();
		
	}

}
