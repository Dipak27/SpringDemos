
public class EmployeeService 
{
	private EmployeeDAO dao;

	public void setDao(EmployeeDAO dao) 
	{
		this.dao = dao;
	}
	public void insert(Employee e)
	{
		dao.insertEmp(e);
		System.out.println("Employee is added");
	}
	public void displayallemp()
	{
		dao.SelectAllEmp();
	}
}
