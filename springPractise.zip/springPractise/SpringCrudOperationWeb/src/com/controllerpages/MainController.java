package com.controllerpages;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.models.Student;
import com.service.impl.StudentServiceImpl;

@Controller
@RequestMapping("/home")
public class MainController 
{
	
	public MainController() {
		System.out.println("Main controller");
	}
	
	@RequestMapping(value="/index",method= RequestMethod.GET)
	public String ShowIndex()
	{
		return "home";
	}
	
	@RequestMapping(value="/view",method= RequestMethod.GET)
	public String ShowAllDetails()
	{
		System.out.println("this is view controller");
		StudentServiceImpl sr=new StudentServiceImpl();
		sr.displayAllStudent();
	   // model.addObject("listStudent", listStudent);
	    
	 
	    return "display";
	}


	
}
