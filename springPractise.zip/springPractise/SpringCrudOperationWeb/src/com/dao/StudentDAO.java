package com.dao;

import java.util.List;

import com.models.Student;

public interface StudentDAO 
{

	public void displayDetails();
	
}
