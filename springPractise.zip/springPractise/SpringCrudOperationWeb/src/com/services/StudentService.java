package com.services;

public interface StudentService {

	public void displayAllStudent();
}
