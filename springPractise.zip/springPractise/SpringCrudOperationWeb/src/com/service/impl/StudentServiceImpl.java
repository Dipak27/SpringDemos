package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.StudentDAO;
import com.models.Student;
import com.services.StudentService;

public class StudentServiceImpl implements StudentService
{
	@Autowired
	private StudentDAO stdao;
	
	public StudentServiceImpl() {
		System.out.println("Service Impl Ctor");
	}
	
	/*public void setStdao(StudentDAO stdao) 
	{
		this.stdao = stdao;
	}*/
	
	@Override
	public void displayAllStudent()
	{
		System.out.println("this is service");
		stdao.displayDetails();
		
		
	}
	
}
