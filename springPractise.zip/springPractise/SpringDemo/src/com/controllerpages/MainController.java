package com.controllerpages;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.services.StudentService;

@Controller
@RequestMapping("/home")
public class MainController 
{
	@Autowired
	private StudentService service;
	
	public MainController() {
		System.out.println("Main controller");
	}
	
	@RequestMapping(value="/index",method= RequestMethod.GET)
	public String ShowIndex()
	{
		return "home";
	}
	
	@RequestMapping(value="/view",method= RequestMethod.GET)
	public String ShowAllDetails()
	{
		System.out.println("this is view controller");
		
		service.displayAllStudent();
	   // model.addObject("listStudent", listStudent);
	    
	 
	    return "display";
	}


	
}
