package com.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.dao.StudentDAO;
import com.models.Student;


@Repository
public class StudentDaoImpl implements StudentDAO
{
	//private JdbcTemplate jt;
	
	
	
	public StudentDaoImpl() {
		super();
		System.out.println("dao costructor......");
	}

	public void setJt(JdbcTemplate jt) {
		//this.jt = jt;
	}



	@Override
	public void displayDetails()
	{
		System.out.println("this is dao implementation");


		
	}


}
